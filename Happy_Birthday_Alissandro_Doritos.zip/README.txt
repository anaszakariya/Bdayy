HAPPY BIRTHDAY WEBSITE
=======================

Files:
- index.html
- birthday-video.mp4

To add the Pretty Little Baby BGM:
1. Put your MP3 in this folder.
2. Rename it to: pretty-little-baby.mp3
3. In index.html, uncomment the <audio> line.

The page is ready for free static hosting.
