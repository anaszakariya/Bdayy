BIRTHDAY SURPRISE FOR AYESHA / ALESSAH

1. Open index.html to preview the page.
2. To add music, place your legally obtained copy of "Bheegi Si Bhaagi Si" in this folder and name it:
   song.mp3
3. Upload the folder to any static website host to turn it into a shareable link.

The page is mobile-friendly and contains the custom message from Zakariyaa.
